﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinAppOpenForm
{
    public interface IForm
    {
        void ChangeTextBoxText(string text);
    }
}
